# phonia
phonia (entynetproject)
# ALERT
Copy of the tool (phonia) I am not the programmer of this tool.
# INSTALACIÓN
chmod 777 phonia.sh
# USO
./phonia.sh
# Created by: entynetproject
